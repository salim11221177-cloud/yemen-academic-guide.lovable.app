import { Link } from "@tanstack/react-router";
import { GraduationCap, LogIn, UserPlus, LogOut, LayoutDashboard, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export function SiteHeader() {
  const { user, roles, signOut } = useAuth();
  const isUniversity = roles.includes("university");
  const isAdmin = roles.includes("admin");
  const dashHref = isAdmin ? "/admin" : isUniversity ? "/university" : "/account";

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-xl">
      <div className="container mx-auto flex h-16 items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-hero shadow-soft">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="hidden sm:block">
            <div className="text-base font-extrabold leading-tight">دليلك الجامعي</div>
            <div className="text-[10px] text-muted-foreground">منصة الجامعات اليمنية</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-1 text-sm">
          <Link to="/" className="px-3 py-2 rounded-lg hover:bg-accent transition" activeOptions={{ exact: true }} activeProps={{ className: "text-primary font-bold" }}>
            الرئيسية
          </Link>
          <Link to="/universities" className="px-3 py-2 rounded-lg hover:bg-accent transition" activeProps={{ className: "text-primary font-bold" }}>
            الجامعات
          </Link>
          <Link to="/register-university" className="px-3 py-2 rounded-lg hover:bg-accent transition" activeProps={{ className: "text-primary font-bold" }}>
            تسجيل جامعة
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Link to="/universities" className="md:hidden">
            <Button variant="ghost" size="icon" aria-label="بحث">
              <Search className="h-4 w-4" />
            </Button>
          </Link>
          {user ? (
            <>
              <Link to={dashHref}>
                <Button variant="outline" size="sm" className="gap-2">
                  <LayoutDashboard className="h-4 w-4" /> <span className="hidden sm:inline">لوحتي</span>
                </Button>
              </Link>
              <Button variant="ghost" size="icon" onClick={signOut} aria-label="خروج">
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <>
              <Link to="/auth">
                <Button variant="ghost" size="sm" className="gap-2">
                  <LogIn className="h-4 w-4" /> <span className="hidden sm:inline">دخول</span>
                </Button>
              </Link>
              <Link to="/register-university">
                <Button variant="hero" size="sm" className="gap-2">
                  <UserPlus className="h-4 w-4" /> <span className="hidden sm:inline">تسجيل جامعة</span>
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
