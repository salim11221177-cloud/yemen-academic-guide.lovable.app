import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, MapPin, Building2, Filter } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/universities/")({
  validateSearch: (s: Record<string, unknown>) => ({ q: typeof s.q === "string" ? s.q : "" }),
  head: () => ({
    meta: [
      { title: "الجامعات اليمنية — دليلك الجامعي" },
      { name: "description", content: "تصفّح جميع الجامعات اليمنية المسجّلة في منصة دليلك الجامعي." },
    ],
  }),
  component: UniversitiesPage,
});

function UniversitiesPage() {
  const search = Route.useSearch();
  const [query, setQuery] = useState(search.q ?? "");
  const [type, setType] = useState<string>("all");

  const { data: universities = [], isLoading } = useQuery({
    queryKey: ["universities", query, type],
    queryFn: async () => {
      let q = supabase
        .from("universities")
        .select("id, name, short_description, logo_url, city, type")
        .eq("status", "active")
        .order("name");
      if (query.trim()) q = q.ilike("name", `%${query.trim()}%`);
      if (type !== "all") q = q.eq("type", type as any);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <SiteHeader />

      <section className="bg-gradient-warm py-12 border-b border-border/60">
        <div className="container mx-auto px-4 sm:px-6">
          <h1 className="text-3xl sm:text-4xl font-black mb-3">الجامعات اليمنية</h1>
          <p className="text-muted-foreground mb-6">استكشف جميع الجامعات المعتمدة في منصتنا</p>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث عن جامعة..."
                className="h-12 ps-11 bg-card shadow-soft"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {[
                { v: "all", l: "الكل" },
                { v: "government", l: "حكومية" },
                { v: "private", l: "خاصة" },
                { v: "technical", l: "تقنية" },
              ].map((t) => (
                <Button
                  key={t.v}
                  variant={type === t.v ? "default" : "outline"}
                  size="sm"
                  onClick={() => setType(t.v)}
                  className="shrink-0"
                >
                  {t.l}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 flex-1">
        <div className="container mx-auto px-4 sm:px-6">
          {isLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-64 rounded-xl bg-muted/50 animate-pulse" />
              ))}
            </div>
          ) : universities.length === 0 ? (
            <Card className="border-dashed bg-muted/30">
              <CardContent className="p-12 text-center">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-bold mb-2">لا توجد نتائج</h3>
                <p className="text-sm text-muted-foreground">جرّب تعديل البحث أو الفلاتر</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {universities.map((u) => (
                <Link key={u.id} to="/universities/$id" params={{ id: u.id }}>
                  <Card className="group h-full hover:shadow-elegant transition-all duration-300 hover:-translate-y-1 overflow-hidden border-border/60">
                    <div className="h-36 bg-gradient-hero relative overflow-hidden">
                      {u.logo_url && (
                        <img src={u.logo_url} alt={u.name} className="absolute inset-0 h-full w-full object-cover opacity-90" loading="lazy" />
                      )}
                    </div>
                    <CardContent className="p-5">
                      <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition">{u.name}</h3>
                      {u.short_description && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{u.short_description}</p>
                      )}
                      <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border/40">
                        {u.city && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{u.city}</span>}
                        <Badge variant="outline" className="text-[10px]">
                          {u.type === "government" ? "حكومية" : u.type === "private" ? "خاصة" : "تقنية"}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
