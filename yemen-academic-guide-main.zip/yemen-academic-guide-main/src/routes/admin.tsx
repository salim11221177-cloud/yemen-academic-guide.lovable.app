import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Shield, Building2, Users, CheckCircle2, XCircle, Eye } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({ component: AdminDashboard });

function AdminDashboard() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const { user, loading, isAdmin } = useAuth();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
    if (!loading && user && !isAdmin) nav({ to: "/account" });
  }, [loading, user, isAdmin, nav]);

  const { data: universities = [] } = useQuery({
    queryKey: ["admin-universities"],
    queryFn: async () => {
      const { data } = await supabase.from("universities").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: isAdmin,
  });

  const { data: stats } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [{ count: total }, { count: active }, { count: pending }] = await Promise.all([
        supabase.from("universities").select("*", { count: "exact", head: true }),
        supabase.from("universities").select("*", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("universities").select("*", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      return { total: total ?? 0, active: active ?? 0, pending: pending ?? 0 };
    },
    enabled: isAdmin,
  });

  async function updateStatus(id: string, status: "active" | "suspended") {
    const { error } = await supabase.from("universities").update({ status }).eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("تم التحديث"); qc.invalidateQueries({ queryKey: ["admin-universities"] }); qc.invalidateQueries({ queryKey: ["admin-stats"] }); }
  }

  if (loading || !isAdmin) return null;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <section className="bg-gradient-warm py-10 border-b border-border/60">
        <div className="container mx-auto px-4 sm:px-6 flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-hero grid place-items-center text-primary-foreground">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black">لوحة الإدارة العامة</h1>
            <p className="text-sm text-muted-foreground">إدارة الجامعات والمستخدمين والاشتراكات</p>
          </div>
        </div>
      </section>

      <section className="py-8">
        <div className="container mx-auto px-4 sm:px-6 grid sm:grid-cols-3 gap-5">
          <StatCard label="إجمالي الجامعات" value={stats?.total ?? 0} icon={Building2} />
          <StatCard label="جامعات مفعّلة" value={stats?.active ?? 0} icon={CheckCircle2} />
          <StatCard label="بانتظار المراجعة" value={stats?.pending ?? 0} icon={Users} />
        </div>
      </section>

      <section className="pb-12">
        <div className="container mx-auto px-4 sm:px-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-black mb-5">إدارة الجامعات</h2>
              <div className="space-y-2">
                {universities.map((u) => (
                  <div key={u.id} className="flex items-center justify-between gap-3 p-4 rounded-lg border border-border/60 bg-muted/20 flex-wrap">
                    <div className="min-w-0 flex-1">
                      <div className="font-bold">{u.name}</div>
                      <div className="text-xs text-muted-foreground">{u.city} • {u.type === "government" ? "حكومية" : u.type === "private" ? "خاصة" : "تقنية"}</div>
                    </div>
                    <Badge variant={u.status === "active" ? "default" : u.status === "pending" ? "secondary" : "destructive"}>
                      {u.status === "active" ? "مفعّلة" : u.status === "pending" ? "بانتظار" : "موقفة"}
                    </Badge>
                    <div className="flex gap-2">
                      <Link to="/universities/$id" params={{ id: u.id }}>
                        <Button variant="ghost" size="icon"><Eye className="h-4 w-4" /></Button>
                      </Link>
                      {u.status !== "active" && (
                        <Button variant="outline" size="sm" onClick={() => updateStatus(u.id, "active")} className="gap-1">
                          <CheckCircle2 className="h-3.5 w-3.5" /> تفعيل
                        </Button>
                      )}
                      {u.status === "active" && (
                        <Button variant="outline" size="sm" onClick={() => updateStatus(u.id, "suspended")} className="gap-1">
                          <XCircle className="h-3.5 w-3.5" /> إيقاف
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                {universities.length === 0 && (
                  <div className="text-center text-sm text-muted-foreground py-8">لا توجد جامعات بعد</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}

function StatCard({ label, value, icon: Icon }: { label: string; value: number; icon: any }) {
  return (
    <Card>
      <CardContent className="p-5 flex items-center justify-between">
        <div>
          <div className="text-xs text-muted-foreground">{label}</div>
          <div className="text-3xl font-black mt-1">{value}</div>
        </div>
        <Icon className="h-8 w-8 text-primary opacity-70" />
      </CardContent>
    </Card>
  );
}
