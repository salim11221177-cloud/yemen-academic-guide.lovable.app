import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Phone, Mail, Globe, Calendar, GraduationCap, ArrowRight, Building2 } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/universities/$id")({
  component: UniversityDetail,
});

function UniversityDetail() {
  const { id } = Route.useParams();

  const { data: university, isLoading } = useQuery({
    queryKey: ["university", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("universities")
        .select("*")
        .eq("id", id)
        .eq("status", "active")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: colleges = [] } = useQuery({
    queryKey: ["colleges", id],
    queryFn: async () => {
      const { data } = await supabase.from("colleges").select("*").eq("university_id", id).order("name");
      return data ?? [];
    },
    enabled: !!university,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container mx-auto px-4 py-20"><div className="h-96 bg-muted/50 rounded-xl animate-pulse" /></div>
      </div>
    );
  }

  if (!university) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container mx-auto px-4 py-20 text-center">
          <Building2 className="h-16 w-16 mx-auto text-muted-foreground/40 mb-4" />
          <h1 className="text-2xl font-bold mb-2">الجامعة غير موجودة</h1>
          <p className="text-muted-foreground mb-6">قد تكون الجامعة موقفة أو محذوفة</p>
          <Link to="/universities"><Button variant="hero">عرض الجامعات</Button></Link>
        </div>
      </div>
    );
  }

  const mapsUrl = university.latitude && university.longitude
    ? `https://www.google.com/maps?q=${university.latitude},${university.longitude}`
    : university.address
    ? `https://www.google.com/maps/search/${encodeURIComponent(university.address)}`
    : null;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="relative bg-gradient-hero text-primary-foreground overflow-hidden">
        {university.cover_url && (
          <img src={university.cover_url} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-primary to-transparent" />
        <div className="relative container mx-auto px-4 sm:px-6 py-16 sm:py-20">
          <Link to="/universities" className="inline-flex items-center gap-1 text-sm opacity-80 hover:opacity-100 mb-6">
            <ArrowRight className="h-4 w-4" /> عودة للجامعات
          </Link>
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
            <div className="h-28 w-28 rounded-2xl bg-card shadow-elegant overflow-hidden shrink-0 grid place-items-center">
              {university.logo_url ? (
                <img src={university.logo_url} alt={university.name} className="h-full w-full object-cover" />
              ) : (
                <GraduationCap className="h-12 w-12 text-primary" />
              )}
            </div>
            <div className="min-w-0">
              <Badge variant="secondary" className="mb-3 bg-gold text-gold-foreground border-0">
                {university.type === "government" ? "جامعة حكومية" : university.type === "private" ? "جامعة خاصة" : "جامعة تقنية"}
              </Badge>
              <h1 className="text-3xl sm:text-5xl font-black mb-3">{university.name}</h1>
              {university.short_description && (
                <p className="text-lg opacity-90 max-w-2xl">{university.short_description}</p>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4 sm:px-6 grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {university.description && (
              <Card>
                <CardContent className="p-6 sm:p-8">
                  <h2 className="text-2xl font-black mb-4">نبذة عن الجامعة</h2>
                  <p className="text-foreground/80 leading-loose whitespace-pre-line">{university.description}</p>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-6 sm:p-8">
                <h2 className="text-2xl font-black mb-6 flex items-center gap-2">
                  <GraduationCap className="h-6 w-6 text-primary" /> الكليات
                </h2>
                {colleges.length === 0 ? (
                  <p className="text-muted-foreground text-sm">لم يتم إضافة كليات بعد.</p>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-3">
                    {colleges.map((c) => (
                      <div key={c.id} className="p-4 rounded-lg border border-border/60 bg-muted/30 hover:bg-accent/50 transition">
                        <h3 className="font-bold">{c.name}</h3>
                        {c.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{c.description}</p>}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <aside className="space-y-5">
            <Card>
              <CardContent className="p-6 space-y-4">
                <h3 className="font-black text-lg mb-2">معلومات التواصل</h3>
                {university.city && <InfoRow icon={MapPin} label={university.city} />}
                {university.address && <InfoRow icon={MapPin} label={university.address} />}
                {university.phone && <InfoRow icon={Phone} label={university.phone} href={`tel:${university.phone}`} />}
                {university.email && <InfoRow icon={Mail} label={university.email} href={`mailto:${university.email}`} />}
                {university.website && <InfoRow icon={Globe} label="الموقع الإلكتروني" href={university.website} />}
                {university.founded_year && <InfoRow icon={Calendar} label={`تأسست عام ${university.founded_year}`} />}
              </CardContent>
            </Card>

            {mapsUrl && (
              <a href={mapsUrl} target="_blank" rel="noopener noreferrer">
                <Button variant="hero" className="w-full gap-2">
                  <MapPin className="h-4 w-4" /> فتح في الخريطة
                </Button>
              </a>
            )}
          </aside>
        </div>
      </section>
    </div>
  );
}

function InfoRow({ icon: Icon, label, href }: { icon: any; label: string; href?: string }) {
  const content = (
    <div className="flex items-start gap-3 text-sm">
      <Icon className="h-4 w-4 mt-0.5 text-primary shrink-0" />
      <span className="min-w-0 break-words">{label}</span>
    </div>
  );
  return href ? <a href={href} className="block hover:text-primary transition">{content}</a> : content;
}
