import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Building2, Plus, Pencil, Trash2, AlertCircle, CheckCircle2, Calendar } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/university")({ component: UniversityDashboard });

function UniversityDashboard() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const { user, loading, isUniversity, isAdmin } = useAuth();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
    if (!loading && user && !isUniversity && !isAdmin) nav({ to: "/account" });
  }, [loading, user, isUniversity, isAdmin, nav]);

  const { data: university } = useQuery({
    queryKey: ["my-university", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("universities").select("*").eq("owner_id", user!.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const { data: subscription } = useQuery({
    queryKey: ["subscription", university?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("subscriptions")
        .select("*")
        .eq("university_id", university!.id)
        .order("end_date", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
    enabled: !!university,
  });

  const { data: colleges = [] } = useQuery({
    queryKey: ["my-colleges", university?.id],
    queryFn: async () => {
      const { data } = await supabase.from("colleges").select("*").eq("university_id", university!.id).order("name");
      return data ?? [];
    },
    enabled: !!university,
  });

  const subActive = subscription && new Date(subscription.end_date) > new Date() && subscription.status === "active";

  if (loading || !user || !university) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="container mx-auto px-4 py-20 text-center">
          {!loading && user && !university ? (
            <Card className="max-w-md mx-auto">
              <CardContent className="p-8">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h2 className="font-bold mb-2">لا يوجد جامعة مسجّلة</h2>
                <p className="text-sm text-muted-foreground mb-4">قم بتسجيل جامعتك للوصول للوحة التحكم.</p>
                <Button variant="hero" onClick={() => nav({ to: "/register-university" })}>تسجيل جامعة</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="h-64 bg-muted/50 rounded-xl animate-pulse max-w-2xl mx-auto" />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <section className="bg-gradient-warm py-10 border-b border-border/60">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex items-start gap-4 flex-wrap">
            <div className="h-16 w-16 rounded-2xl bg-card shadow-soft grid place-items-center shrink-0">
              {university.logo_url ? <img src={university.logo_url} className="h-full w-full object-cover rounded-2xl" alt="" /> : <Building2 className="h-8 w-8 text-primary" />}
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl sm:text-3xl font-black truncate">{university.name}</h1>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <Badge variant={university.status === "active" ? "default" : "secondary"}>
                  {university.status === "active" ? "مفعّلة" : university.status === "pending" ? "قيد المراجعة" : "موقفة"}
                </Badge>
                {subActive ? (
                  <Badge className="bg-emerald-600 hover:bg-emerald-700 gap-1"><CheckCircle2 className="h-3 w-3" /> اشتراك فعّال</Badge>
                ) : (
                  <Badge variant="destructive" className="gap-1"><AlertCircle className="h-3 w-3" /> الاشتراك منتهٍ</Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {!subActive && (
        <div className="container mx-auto px-4 sm:px-6 pt-6">
          <Card className="border-destructive/30 bg-destructive/5">
            <CardContent className="p-5 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">انتهى اشتراكك</p>
                <p className="text-sm text-muted-foreground">يرجى التواصل مع الإدارة لتجديد الاشتراك واستعادة كامل الصلاحيات.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <section className="py-8">
        <div className="container mx-auto px-4 sm:px-6 grid lg:grid-cols-3 gap-6">
          {/* Stats */}
          <Card>
            <CardContent className="p-5">
              <div className="text-xs text-muted-foreground">عدد الكليات</div>
              <div className="text-3xl font-black mt-1">{colleges.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-xs text-muted-foreground">نوع الجامعة</div>
              <div className="text-xl font-bold mt-1">
                {university.type === "government" ? "حكومية" : university.type === "private" ? "خاصة" : "تقنية"}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> ينتهي الاشتراك</div>
              <div className="text-xl font-bold mt-1">
                {subscription ? new Date(subscription.end_date).toLocaleDateString("ar-EG") : "—"}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Colleges management */}
      <section className="pb-12">
        <div className="container mx-auto px-4 sm:px-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
                <h2 className="text-xl font-black">إدارة الكليات</h2>
                <CollegeDialog universityId={university.id} disabled={!subActive} onSaved={() => qc.invalidateQueries({ queryKey: ["my-colleges"] })} />
              </div>

              {colleges.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground text-sm">لا توجد كليات بعد. ابدأ بإضافة أول كلية.</div>
              ) : (
                <div className="space-y-2">
                  {colleges.map((c) => (
                    <div key={c.id} className="flex items-center justify-between gap-3 p-4 rounded-lg border border-border/60 bg-muted/20">
                      <div className="min-w-0">
                        <div className="font-bold truncate">{c.name}</div>
                        {c.description && <div className="text-xs text-muted-foreground truncate">{c.description}</div>}
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <CollegeDialog
                          universityId={university.id}
                          disabled={!subActive}
                          existing={c}
                          onSaved={() => qc.invalidateQueries({ queryKey: ["my-colleges"] })}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          disabled={!subActive}
                          onClick={async () => {
                            if (!confirm(`حذف كلية ${c.name}؟`)) return;
                            const { error } = await supabase.from("colleges").delete().eq("id", c.id);
                            if (error) toast.error(error.message);
                            else { toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["my-colleges"] }); }
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}

function CollegeDialog({ universityId, existing, disabled, onSaved }: { universityId: string; existing?: any; disabled?: boolean; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    const payload = {
      name: String(fd.get("name") ?? "").trim().slice(0, 150),
      description: String(fd.get("description") ?? "").trim().slice(0, 500) || null,
      university_id: universityId,
    };
    if (!payload.name) { toast.error("الاسم مطلوب"); setSaving(false); return; }
    const { error } = existing
      ? await supabase.from("colleges").update(payload).eq("id", existing.id)
      : await supabase.from("colleges").insert(payload);
    setSaving(false);
    if (error) toast.error(error.message);
    else { toast.success("تم الحفظ"); setOpen(false); onSaved(); }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {existing ? (
          <Button variant="ghost" size="icon" disabled={disabled}><Pencil className="h-4 w-4" /></Button>
        ) : (
          <Button variant="hero" size="sm" disabled={disabled} className="gap-2"><Plus className="h-4 w-4" /> إضافة كلية</Button>
        )}
      </DialogTrigger>
      <DialogContent dir="rtl">
        <DialogHeader><DialogTitle>{existing ? "تعديل كلية" : "إضافة كلية جديدة"}</DialogTitle></DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <Label htmlFor="cname">اسم الكلية *</Label>
            <Input id="cname" name="name" defaultValue={existing?.name} required maxLength={150} className="mt-1.5" />
          </div>
          <div>
            <Label htmlFor="cdesc">وصف مختصر</Label>
            <Textarea id="cdesc" name="description" defaultValue={existing?.description ?? ""} rows={3} maxLength={500} className="mt-1.5" />
          </div>
          <Button type="submit" variant="hero" className="w-full" disabled={saving}>
            {saving ? "جارٍ الحفظ..." : "حفظ"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
