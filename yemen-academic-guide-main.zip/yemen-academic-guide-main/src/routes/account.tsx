import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, GraduationCap, Bell } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/account")({ component: AccountPage });

function AccountPage() {
  const nav = useNavigate();
  const { user, loading, signOut } = useAuth();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
  }, [user, loading, nav]);

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="bg-gradient-warm py-12 border-b border-border/60">
        <div className="container mx-auto px-4 sm:px-6 flex items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-gradient-hero grid place-items-center text-primary-foreground shrink-0">
            <User className="h-7 w-7" />
          </div>
          <div className="min-w-0">
            <h1 className="text-2xl sm:text-3xl font-black truncate">{profile?.full_name ?? user.email}</h1>
            <p className="text-sm text-muted-foreground truncate">{user.email}</p>
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-4 sm:px-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <Card>
            <CardContent className="p-6">
              <GraduationCap className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-bold mb-1">تصفّح الجامعات</h3>
              <p className="text-sm text-muted-foreground mb-4">استكشف الجامعات اليمنية والكليات والتخصصات.</p>
              <Button variant="outline" size="sm" onClick={() => nav({ to: "/universities" })}>عرض الجامعات</Button>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <Bell className="h-8 w-8 text-gold mb-3" />
              <h3 className="font-bold mb-1">الإشعارات</h3>
              <p className="text-sm text-muted-foreground mb-4">سيتم عرض إشعاراتك الأكاديمية هنا قريباً.</p>
              <Button variant="outline" size="sm" disabled>قريباً</Button>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <User className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-bold mb-1">الحساب</h3>
              <p className="text-sm text-muted-foreground mb-4">تسجيل الخروج من حسابك في المنصة.</p>
              <Button variant="outline" size="sm" onClick={signOut}>تسجيل الخروج</Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
