import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Building2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SiteHeader } from "@/components/SiteHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

export const Route = createFileRoute("/register-university")({
  head: () => ({
    meta: [
      { title: "تسجيل جامعة جديدة — دليلك الجامعي" },
      { name: "description", content: "سجّل جامعتك في منصة دليلك الجامعي واحصل على لوحة تحكم متكاملة." },
    ],
  }),
  component: RegisterUniversityPage,
});

const schema = z.object({
  name: z.string().trim().min(3, "اسم الجامعة مطلوب").max(150),
  short_description: z.string().trim().max(200).optional(),
  description: z.string().trim().max(2000).optional(),
  type: z.enum(["government", "private", "technical"]),
  city: z.string().trim().max(80).optional(),
  address: z.string().trim().max(200).optional(),
  phone: z.string().trim().max(30).optional(),
  email: z.string().trim().email("بريد غير صحيح").max(255).optional().or(z.literal("")),
  website: z.string().trim().url("رابط غير صحيح").max(255).optional().or(z.literal("")),
  founded_year: z.coerce.number().int().min(1900).max(new Date().getFullYear()).optional().or(z.literal("")),
  plan: z.enum(["monthly", "yearly"]),
});

function RegisterUniversityPage() {
  const nav = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      toast.info("سجّل دخولك أولاً لتسجيل جامعة");
      nav({ to: "/auth" });
    }
  }, [authLoading, user, nav]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    const fd = new FormData(e.currentTarget);
    try {
      const data = schema.parse({
        name: fd.get("name"),
        short_description: fd.get("short_description") || undefined,
        description: fd.get("description") || undefined,
        type: fd.get("type"),
        city: fd.get("city") || undefined,
        address: fd.get("address") || undefined,
        phone: fd.get("phone") || undefined,
        email: fd.get("email") || "",
        website: fd.get("website") || "",
        founded_year: fd.get("founded_year") || "",
        plan: fd.get("plan"),
      });

      const { data: uni, error } = await supabase
        .from("universities")
        .insert({
          owner_id: user.id,
          name: data.name,
          short_description: data.short_description ?? null,
          description: data.description ?? null,
          type: data.type,
          status: "pending",
          city: data.city ?? null,
          address: data.address ?? null,
          phone: data.phone ?? null,
          email: data.email || null,
          website: data.website || null,
          founded_year: data.founded_year ? Number(data.founded_year) : null,
        })
        .select()
        .single();
      if (error) throw error;

      // Subscription
      const days = data.plan === "yearly" ? 365 : 30;
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + days);
      await supabase.from("subscriptions").insert({
        university_id: uni.id,
        plan: data.plan,
        status: "active",
        end_date: endDate.toISOString(),
      });

      // Grant university role
      await supabase.from("user_roles").insert({
        user_id: user.id,
        role: "university",
        university_id: uni.id,
      });

      toast.success("تم تسجيل الجامعة. سيتم مراجعة الطلب قريباً.");
      nav({ to: "/university" });
    } catch (err: any) {
      toast.error(err.message ?? "حدث خطأ في التسجيل");
    } finally {
      setSubmitting(false);
    }
  }

  if (authLoading) return null;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="bg-gradient-warm py-12 border-b border-border/60">
        <div className="container mx-auto px-4 sm:px-6">
          <Badge>
            <Building2 className="h-3.5 w-3.5" /> تسجيل جامعة
          </Badge>
          <h1 className="text-3xl sm:text-4xl font-black mt-4">سجّل جامعتك في المنصة</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">أكمل البيانات أدناه لإنشاء حساب جامعتك والاستفادة من جميع المميزات.</p>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-4 sm:px-6 max-w-3xl">
          <Card>
            <CardContent className="p-6 sm:p-8">
              <form onSubmit={onSubmit} className="space-y-5">
                <Field label="اسم الجامعة *" name="name" required maxLength={150} />
                <Field label="وصف مختصر" name="short_description" maxLength={200} placeholder="جملة قصيرة تظهر في البطاقة" />
                <div>
                  <Label htmlFor="description">نبذة تفصيلية</Label>
                  <Textarea id="description" name="description" rows={5} maxLength={2000} className="mt-1.5" />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="type">نوع الجامعة *</Label>
                    <Select name="type" defaultValue="government" required>
                      <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="government">حكومية</SelectItem>
                        <SelectItem value="private">خاصة</SelectItem>
                        <SelectItem value="technical">تقنية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Field label="سنة التأسيس" name="founded_year" type="number" min={1900} max={new Date().getFullYear()} />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="المدينة" name="city" maxLength={80} />
                  <Field label="العنوان" name="address" maxLength={200} />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="الهاتف" name="phone" type="tel" maxLength={30} />
                  <Field label="البريد الإلكتروني" name="email" type="email" maxLength={255} />
                </div>
                <Field label="الموقع الإلكتروني" name="website" type="url" placeholder="https://" />

                <div className="pt-2">
                  <Label className="mb-3 block">نوع الاشتراك *</Label>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <label className="cursor-pointer">
                      <input type="radio" name="plan" value="monthly" defaultChecked className="peer sr-only" />
                      <div className="p-4 rounded-xl border-2 border-border peer-checked:border-primary peer-checked:bg-primary/5 transition">
                        <div className="font-bold">شهري</div>
                        <div className="text-xs text-muted-foreground mt-1">صلاحية 30 يوماً</div>
                      </div>
                    </label>
                    <label className="cursor-pointer">
                      <input type="radio" name="plan" value="yearly" className="peer sr-only" />
                      <div className="p-4 rounded-xl border-2 border-border peer-checked:border-primary peer-checked:bg-primary/5 transition">
                        <div className="font-bold flex items-center gap-2">سنوي <span className="text-[10px] bg-gold text-gold-foreground px-2 py-0.5 rounded-full">وفّر أكثر</span></div>
                        <div className="text-xs text-muted-foreground mt-1">صلاحية 365 يوماً</div>
                      </div>
                    </label>
                  </div>
                </div>

                <Button type="submit" variant="hero" size="lg" className="w-full mt-4" disabled={submitting}>
                  {submitting ? "جارٍ التسجيل..." : "تسجيل الجامعة"}
                  <ArrowRight className="h-4 w-4 mr-2" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}

function Field({ label, name, ...props }: { label: string; name: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} {...props} className="mt-1.5" />
    </div>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-gold/20 text-gold-foreground border border-gold/30">{children}</span>;
}
