import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { GraduationCap, Mail, Lock, User, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "تسجيل الدخول — دليلك الجامعي" },
      { name: "description", content: "سجّل الدخول أو أنشئ حساباً جديداً في منصة دليلك الجامعي." },
    ],
  }),
  component: AuthPage,
});

const signInSchema = z.object({
  email: z.string().trim().email("بريد إلكتروني غير صحيح").max(255),
  password: z.string().min(6, "كلمة المرور 6 أحرف على الأقل").max(128),
});
const signUpSchema = signInSchema.extend({
  fullName: z.string().trim().min(2, "الاسم مطلوب").max(100),
});

function AuthPage() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    try {
      if (mode === "signup") {
        const data = signUpSchema.parse({
          fullName: fd.get("fullName"),
          email: fd.get("email"),
          password: fd.get("password"),
        });
        const { error } = await supabase.auth.signUp({
          email: data.email,
          password: data.password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { full_name: data.fullName },
          },
        });
        if (error) throw error;
        toast.success("تم إنشاء الحساب بنجاح");
        nav({ to: "/" });
      } else {
        const data = signInSchema.parse({ email: fd.get("email"), password: fd.get("password") });
        const { error } = await supabase.auth.signInWithPassword(data);
        if (error) throw error;
        toast.success("مرحباً بك مجدداً");
        nav({ to: "/" });
      }
    } catch (err: any) {
      toast.error(err.message ?? "حدث خطأ");
    } finally {
      setLoading(false);
    }
  }

  async function googleSignIn() {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) toast.error("فشل تسجيل الدخول بـ Google");
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background" dir="rtl">
      {/* Form side */}
      <div className="flex flex-col p-6 sm:p-10">
        <Link to="/" className="flex items-center gap-2 self-start">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-hero shadow-soft">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-extrabold">دليلك الجامعي</span>
        </Link>

        <div className="flex-1 flex items-center justify-center py-10">
          <div className="w-full max-w-md">
            <h1 className="text-3xl font-black mb-2">
              {mode === "signin" ? "أهلاً بعودتك" : "أنشئ حسابك"}
            </h1>
            <p className="text-muted-foreground mb-8">
              {mode === "signin" ? "سجّل الدخول لمتابعة رحلتك الأكاديمية" : "انضم لمنصة الجامعات اليمنية"}
            </p>

            <Tabs value={mode} onValueChange={(v) => setMode(v as any)} className="mb-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">دخول</TabsTrigger>
                <TabsTrigger value="signup">حساب جديد</TabsTrigger>
              </TabsList>
            </Tabs>

            <Button type="button" variant="outline" className="w-full h-11 mb-4" onClick={googleSignIn}>
              <svg className="h-4 w-4 ml-2" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
              المتابعة بـ Google
            </Button>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
              <span className="relative bg-background px-3 text-xs text-muted-foreground mx-auto block w-fit">أو</span>
            </div>

            <form onSubmit={onSubmit} className="space-y-4">
              {mode === "signup" && (
                <div>
                  <Label htmlFor="fullName">الاسم الكامل</Label>
                  <div className="relative mt-1.5">
                    <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="fullName" name="fullName" required maxLength={100} className="ps-10 h-11" placeholder="أحمد محمد" />
                  </div>
                </div>
              )}
              <div>
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <div className="relative mt-1.5">
                  <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="email" name="email" type="email" required maxLength={255} className="ps-10 h-11" placeholder="name@example.com" />
                </div>
              </div>
              <div>
                <Label htmlFor="password">كلمة المرور</Label>
                <div className="relative mt-1.5">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="password" name="password" type="password" required minLength={6} maxLength={128} className="ps-10 h-11" placeholder="••••••••" />
                </div>
              </div>

              <Button type="submit" variant="hero" className="w-full h-11 mt-2" disabled={loading}>
                {loading ? "جارٍ..." : mode === "signin" ? "تسجيل الدخول" : "إنشاء الحساب"}
                <ArrowRight className="h-4 w-4 mr-2" />
              </Button>
            </form>

            <p className="text-xs text-muted-foreground text-center mt-6">
              بإنشاء حساب أنت توافق على شروط استخدام منصة دليلك الجامعي.
            </p>
          </div>
        </div>
      </div>

      {/* Decorative side */}
      <div className="hidden lg:flex relative bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, white 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
        <div className="relative z-10 p-16 text-primary-foreground flex flex-col justify-end">
          <GraduationCap className="h-16 w-16 mb-6 text-gold" />
          <h2 className="text-4xl font-black mb-4 leading-tight">
            رحلتك الأكاديمية تبدأ من هنا
          </h2>
          <p className="text-lg opacity-90 max-w-md">
            انضم إلى آلاف الطلاب والجامعات اليمنية في منصة موحّدة تربطك بالمعرفة والفرص.
          </p>
        </div>
      </div>
    </div>
  );
}
