import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, GraduationCap, Building2, MapPin, Sparkles, ShieldCheck, BellRing, Users, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SiteHeader } from "@/components/SiteHeader";
import { supabase } from "@/integrations/supabase/client";
import heroImg from "@/assets/hero-yemen.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "دليلك الجامعي — منصة الجامعات اليمنية الموحدة" },
      { name: "description", content: "اكتشف جميع الجامعات اليمنية، الكليات، التخصصات، والإعلانات الأكاديمية في منصة واحدة احترافية." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { data: universities = [] } = useQuery({
    queryKey: ["universities", "featured"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("universities")
        .select("id, name, short_description, logo_url, city, type")
        .eq("status", "active")
        .order("created_at", { ascending: false })
        .limit(6);
      if (error) throw error;
      return data;
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["stats"],
    queryFn: async () => {
      const [{ count: uniCount }, { count: colCount }] = await Promise.all([
        supabase.from("universities").select("*", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("colleges").select("*", { count: "exact", head: true }),
      ]);
      return { universities: uniCount ?? 0, colleges: colCount ?? 0 };
    },
  });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <SiteHeader />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img
            src={heroImg}
            alt="عمارة يمنية تقليدية"
            className="h-full w-full object-cover"
            width={1920}
            height={1080}
            fetchPriority="high"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
        </div>

        <div className="container mx-auto px-4 sm:px-6 py-20 sm:py-28 lg:py-36">
          <div className="max-w-3xl">
            <Badge variant="outline" className="mb-6 gap-2 bg-background/80 backdrop-blur border-gold/40 text-gold-foreground py-1.5 px-4">
              <Sparkles className="h-3.5 w-3.5 text-gold" />
              المنصة الأولى للجامعات اليمنية
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black leading-[1.1] tracking-tight">
              بوابتك إلى <span className="text-gradient-hero">الجامعات اليمنية</span>
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-2xl leading-relaxed">
              استكشف الجامعات والكليات والتخصصات، تابع الإعلانات الأكاديمية،
              وتواصل مع مؤسستك التعليمية — كل شيء في منصة واحدة احترافية.
            </p>

            {/* Search */}
            <form action="/universities" className="mt-8 flex flex-col sm:flex-row gap-3 max-w-2xl">
              <div className="relative flex-1">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  name="q"
                  placeholder="ابحث عن جامعة، كلية، أو تخصص..."
                  className="h-14 ps-12 pe-4 text-base bg-card shadow-elegant border-border/60 rounded-xl"
                />
              </div>
              <Button type="submit" variant="hero" size="lg" className="h-14 px-8 rounded-xl text-base">
                بحث
              </Button>
            </form>

            <div className="mt-8 flex flex-wrap gap-6 text-sm">
              <Stat value={stats?.universities ?? 0} label="جامعة مفعّلة" icon={Building2} />
              <Stat value={stats?.colleges ?? 0} label="كلية" icon={GraduationCap} />
              <Stat value="24/7" label="دعم مستمر" icon={ShieldCheck} />
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-20 bg-gradient-warm">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <Badge variant="secondary" className="mb-4">المميزات</Badge>
            <h2 className="text-3xl sm:text-4xl font-black">
              منصة شاملة لكل احتياجاتك الأكاديمية
            </h2>
            <p className="mt-4 text-muted-foreground text-lg">
              تجربة موحّدة للطلاب والجامعات والإدارة الأكاديمية
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f) => (
              <Card key={f.title} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-1 border-border/60 bg-card">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-xl bg-gradient-hero grid place-items-center text-primary-foreground mb-4 shadow-soft group-hover:shadow-glow transition">
                    <f.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* UNIVERSITIES */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
            <div>
              <Badge variant="secondary" className="mb-3">الجامعات</Badge>
              <h2 className="text-3xl sm:text-4xl font-black">الجامعات المشتركة</h2>
              <p className="mt-2 text-muted-foreground">جامعات يمنية رائدة على المنصة</p>
            </div>
            <Link to="/universities">
              <Button variant="outline" className="gap-2">
                عرض الكل <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {universities.length === 0 ? (
            <Card className="border-dashed bg-muted/30">
              <CardContent className="p-12 text-center">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-bold mb-2">لا توجد جامعات بعد</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  كن أول جامعة تنضم إلى منصة دليلك الجامعي
                </p>
                <Link to="/register-university">
                  <Button variant="hero">سجل جامعتك الآن</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {universities.map((u) => (
                <Link key={u.id} to="/universities/$id" params={{ id: u.id }}>
                  <Card className="group h-full hover:shadow-elegant transition-all duration-300 hover:-translate-y-1 overflow-hidden border-border/60">
                    <div className="h-32 bg-gradient-hero relative overflow-hidden">
                      {u.logo_url && (
                        <img src={u.logo_url} alt={u.name} className="absolute inset-0 h-full w-full object-cover opacity-90" />
                      )}
                    </div>
                    <CardContent className="p-5">
                      <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition">{u.name}</h3>
                      {u.short_description && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{u.short_description}</p>
                      )}
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        {u.city && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{u.city}</span>}
                        <Badge variant="outline" className="text-[10px]">{typeLabel(u.type)}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-warm">
        <div className="container mx-auto px-4 sm:px-6">
          <Card className="overflow-hidden border-0 shadow-elegant">
            <div className="bg-gradient-hero p-10 sm:p-16 text-center text-primary-foreground">
              <h2 className="text-3xl sm:text-4xl font-black mb-4">هل تمثّل جامعة؟</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto mb-8">
                انضم إلى دليلك الجامعي وقدّم لطلابك تجربة رقمية احترافية مع لوحة تحكم متكاملة لإدارة بيانات جامعتك.
              </p>
              <Link to="/register-university">
                <Button size="lg" className="bg-gold text-gold-foreground hover:brightness-110 h-12 px-8 text-base font-bold">
                  ابدأ الاشتراك الآن
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </section>

      <footer className="border-t border-border/60 py-10 bg-card">
        <div className="container mx-auto px-4 sm:px-6 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} دليلك الجامعي. منصة الجامعات اليمنية الموحدة.
        </div>
      </footer>
    </div>
  );
}

function Stat({ value, label, icon: Icon }: { value: string | number; label: string; icon: any }) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-4 w-4 text-gold" />
      <span className="font-bold">{value}</span>
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}

function typeLabel(t: string) {
  return t === "government" ? "حكومية" : t === "private" ? "خاصة" : "تقنية";
}

const features = [
  { icon: Search, title: "بحث ذكي وسريع", desc: "ابحث في الجامعات والتخصصات والإعلانات بنتائج فورية ودقيقة." },
  { icon: Building2, title: "ملف جامعي كامل", desc: "بيانات شاملة عن كل جامعة: الكليات، الموقع، التواصل، والتفاصيل." },
  { icon: BellRing, title: "إعلانات وإشعارات", desc: "تابع آخر الإعلانات الأكاديمية واستقبل الإشعارات لحظياً." },
  { icon: ShieldCheck, title: "أمان وحماية", desc: "نظام صلاحيات متقدم وحماية كاملة للبيانات الحساسة." },
  { icon: Users, title: "تجربة متعددة الأدوار", desc: "واجهات مخصصة للطالب والجامعة والإدارة العامة." },
  { icon: MapPin, title: "خرائط تفاعلية", desc: "اعرف موقع الجامعة بدقة عبر تكامل خرائط Google." },
];
